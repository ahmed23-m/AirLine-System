#pragma once
#include "Account.h"
#include "Flight.h"
using namespace System;
ref class Admin :public Account 
{

};

