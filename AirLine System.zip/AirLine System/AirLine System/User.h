#pragma once
#include "Account.h"
ref class User :public Account
{
};

